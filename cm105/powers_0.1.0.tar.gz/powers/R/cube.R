#' @export
cube <- function(x) pow(x,3)
